CreateThread(function() end)
