# Bone Bangerz Realistic PVE Server (Condensed Mega Pack)
Drop-in server scaffold that groups Bonezz add-ons by category and boots a QBCore stack.
- Endpoints set for ZAP: 147.189.169.5:30412 (TCP/UDP)
- sv_maxclients = 10
- vehiclekeys off
- Includes recipe.yaml to fetch deps (oxmysql/ox_lib), PolyZone, qb-core stack, Illenium.
- Put your real Bonezz scripts in the category folders and keep fxmanifest.lua per resource.
